package com.pfms.Personal_Finance_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalFinanceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
